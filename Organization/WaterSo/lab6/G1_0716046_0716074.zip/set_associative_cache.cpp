#include <bits/stdc++.h>
using namespace std;
const unsigned g_unMaxBits = 32;

string Hex2Bin(const string &s)
{
    stringstream ss;
    ss << hex << s;
    unsigned n;
    ss >> n;
    bitset<g_unMaxBits> b(n);

    unsigned x = 0;
    return b.to_string();// - 4 * (s.length() - x
}
int Bin2Dec(string &s)
{
    int ans = 0;
    for (int i = 0; i < s.size(); i++)
    {
        ans *= 2;
        int c = (int)(s[i] - '0');
        ans += (c);
    }
    return ans;
}
int main()
{
    vector<int> ccsize{1, 2, 4, 8, 16, 32, 64};
    vector<int> way{1, 2, 4, 8};

    for (int i = 0; i < 7; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            int off = 6;
            int index_size = i + 10 - (off)-j;
            vector<vector<string>> Cache(pow(2, index_size), vector<string>(vector<string>(way[j], "")));
            ifstream input("LRU.txt");

            string str;
            int hit = 0;
            int miss = 0;
            while (getline(input, str))
            {
                string target = Hex2Bin(str);
                string str = target.substr(32 - index_size - off, index_size);
                int index = Bin2Dec(str);
                string tag = target.substr(0, 32 - index_size - off);
                vector<string>::iterator it = find(Cache[index].begin(), Cache[index].end(), tag);
                if (it != Cache[index].end())
                {
                    string temp = *it;
                    Cache[index].erase(it);
                    vector<string>::iterator blank = find(Cache[index].begin(), Cache[index].end(), "");
                    hit++;
                    if (blank != Cache[index].end())
                    {
                        *blank = temp;
                        Cache[index].push_back("");

                    }else{
                        Cache[index].push_back(temp);
                    }

                }
                else
                {
                    miss++;

                    vector<string>::iterator blank = find(Cache[index].begin(), Cache[index].end(), "");
                    if (blank != Cache[index].end())
                    {
                        *blank = tag;

                    }
                    else
                    {
                        Cache[index].erase(Cache[index].begin());
                        Cache[index].push_back(tag);
                    }

                }
                target.resize(0);
            }
            cout << way[j] << "-way" << endl;

            cout << "Cache size: " << ccsize[i] << "K" << endl;
            cout << "Block size: " << 64 << endl;
            cout << "Hit rate: " << (float)hit * 100. / (hit + miss) << "%"
                 << "(" << hit << "), "
                 << "Miss rate: " << (float)miss * 100. / (hit + miss) << "%"
                 << "(" << miss << "), " << endl;
            cout << endl;
        }

    }
    return 0;
}