#include <bits/stdc++.h>
using namespace std;
const unsigned g_unMaxBits = 32;

string Hex2Bin(const string &s)
{
    stringstream ss;
    ss << hex << s;
    unsigned n;
    ss >> n;
    bitset<g_unMaxBits> b(n);

    unsigned x = 0;
    return b.to_string().substr(32 - 4 * (s.length() - x));
}
int Bin2Dec(string &s)
{
    int ans = 0;
    for (int i = 0; i < s.size(); i++)
    {
        ans *= 2;
        int c = (int)(s[i] - '0');
        ans += (c);
    }
    return ans;
}
int main()
{
    vector<int> ccsize{4,16,64,256};
    vector<int> bksize{16,32, 64,128, 256};

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            int off = j+4;
            int index_size = (i+1)*2+10-(off);
            vector<pair<bool, string>> Cache(pow(2,index_size), pair<bool, string>(0, ""));
            ifstream input("DCACHE.txt");
            ifstream input_I("ICACHE.txt");

            string str;
            int hit = 0;
            int miss = 0;
            while (getline(input, str))
            {
                string target = Hex2Bin(str);
                string str = target.substr(32-index_size-off, index_size);
                int index = Bin2Dec(str);
                string tag = target.substr(0, 32 - index_size - off);
                if (Cache[index].first)
                {
                    if (Cache[index].second == tag)
                    {
                        hit++;
                        continue;
                    }
                }
                else
                {
                    Cache[index].first = 1;
                    Cache[index].second = tag;
                    miss++;
                }
                target.resize(0);
            }
            cout << "DCACHE" << endl;

            cout << "Cache size: " << ccsize[i] << "K" << endl;
            cout << "Block size: " << bksize[j] << endl;
            cout << "Hit rate: " << (float)hit * 100. / (hit + miss) << "%"
                 << "(" << hit << "), "
                 << "Miss rate: " << (float)miss * 100. / (hit + miss) << "%"
                 << "(" << miss << "), " << endl;
                 cout<<endl;

            hit = 0;
            miss = 0;
            vector<pair<bool, string>> Cache_I(pow(2, index_size), pair<bool, string>(0, ""));
            while (getline(input_I, str))
            {
                string target = Hex2Bin(str);
                string str = target.substr(32 - index_size - off, index_size);
                int index = Bin2Dec(str);
                string tag = target.substr(0, 32 - index_size - off);
                if (Cache_I[index].first)
                {
                    if (Cache_I[index].second == tag)
                    {
                        hit++;
                        continue;
                    }
                }
                else
                {
                    Cache_I[index].first = 1;
                    Cache_I[index].second = tag;
                    miss++;
                }
                target.resize(0);
            }
            cout<<"ICACHE"<<endl;
            cout<<"Cache size: "<<ccsize[i]<<"K"<<endl;
            cout<<"Block size: "<<bksize[j]<<endl;
            cout << "Hit rate: " << (float)hit * 100. / (hit + miss) << "%"
                 << "(" << hit << "), "
                 << "Miss rate: " << (float)miss * 100. / (hit + miss) << "%"
                 << "(" << miss << "), " << endl;
                 cout<<endl;
        }
    }

        return 0;
    }